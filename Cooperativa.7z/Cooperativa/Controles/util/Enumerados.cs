﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controles.util
{
    public class Enumerados
    {
        public enum enumRequerido { NO, SI };

        public enum enumTipos { Ninguna, Fecha, TelefonoConArea, Decimal, Numero, Letra, Email };
    }
}
