﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controles.buttons
{
    public partial class btnAccionesSuministros:gesButton
    {
        public btnAccionesSuministros() {
            this.Size = new System.Drawing.Size(170, 60);
            this.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

        }
    }
}
