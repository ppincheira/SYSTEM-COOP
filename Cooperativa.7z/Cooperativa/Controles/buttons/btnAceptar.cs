﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controles.buttons
{
    public partial class btnAceptar : gesButton
    {
        public btnAceptar()
        {
            //Text = "[F2] ACEPTAR";
            Image = Resources.Iconos.aceptar;
            Size = new System.Drawing.Size(80, 60);
            //UseVisualStyleBackColor = true;
            //BackColor = System.Drawing.Color.Blue;

        }
         
    }
}
