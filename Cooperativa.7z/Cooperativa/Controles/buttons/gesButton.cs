﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controles.buttons
{
     public class gesButton: System.Windows.Forms.Button
    {
        public string FUN_CODIGO;
        public gesButton() {

            //BackColor = System.Drawing.Color.Blue;
            //BackColor = System.Drawing.Color.Blue;


        }


    }
}
