﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controles.textBoxes
{
    public class txtObservaciones:gesTextBox
    {
        public txtObservaciones() {
            this.Multiline = true;
        }
    }
}
