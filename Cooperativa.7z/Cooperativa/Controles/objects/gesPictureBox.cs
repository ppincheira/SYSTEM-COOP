﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controles.objects
{    
    public class gesPictureBox : System.Windows.Forms.PictureBox
    {
    }
}
