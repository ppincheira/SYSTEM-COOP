﻿namespace UI
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvTest = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonCrudGrilla = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnRutas = new System.Windows.Forms.Button();
            this.btnPersonalizado4 = new Controles.btnPersonalizado();
            this.btnPersonalizado3 = new Controles.btnPersonalizado();
            this.btnPersonalizado2 = new Controles.btnPersonalizado();
            this.btnPersonalizado1 = new Controles.btnPersonalizado();
            this.btnPersonalizado8 = new Controles.btnPersonalizado();
            this.btnPersonalizado9 = new Controles.btnPersonalizado();
            this.btnPersonalizado5 = new Controles.btnPersonalizado();
            this.btnPersonalizado6 = new Controles.btnPersonalizado();
            this.btnPersonalizado7 = new Controles.btnPersonalizado();
            this.gesTextBox1 = new Controles.textBoxes.gesTextBox();
            this.gesTextBox2 = new Controles.textBoxes.gesTextBox();
            this.gesTextBox3 = new Controles.textBoxes.gesTextBox();
            this.btnTiposMedidores = new System.Windows.Forms.Button();
            this.btnFabricantes = new System.Windows.Forms.Button();
            this.btnMedidoresModelos = new Controles.btnPersonalizado();
            this.btnMedidores = new Controles.btnPersonalizado();
            this.categorias = new Controles.btnPersonalizado();
            this.btnMedidoresMasivos = new Controles.btnPersonalizado();
            this.btnTiposConexiones = new Controles.btnPersonalizado();
            this.btnDeptos = new System.Windows.Forms.Button();
            this.btnLectura = new System.Windows.Forms.Button();
            this.btnTiposIva = new System.Windows.Forms.Button();
            this.btnServicios = new System.Windows.Forms.Button();
            this.btnSuministros = new System.Windows.Forms.Button();
            this.btnPersonas = new Controles.btnPersonalizado();
            this.btnUsuarios = new Controles.btnPersonalizado();
            this.button3 = new System.Windows.Forms.Button();
            this.btnTiposComprobantes = new Controles.btnPersonalizado();
            this.btnRoles = new System.Windows.Forms.Button();
            this.btnConceptos = new System.Windows.Forms.Button();
            this.btnUnidadesMedida = new System.Windows.Forms.Button();
            this.btnBarrios = new System.Windows.Forms.Button();
            this.btnFuncionalidadesRoles = new System.Windows.Forms.Button();
            this.btnFuncionalidadesUsuarios = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvTest
            // 
            this.dgvTest.Location = new System.Drawing.Point(16, 377);
            this.dgvTest.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvTest.Name = "dgvTest";
            this.dgvTest.Size = new System.Drawing.Size(320, 68);
            this.dgvTest.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(456, 292);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(167, 34);
            this.button1.TabIndex = 8;
            this.button1.Text = " BUSCADOR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonCrudGrilla
            // 
            this.buttonCrudGrilla.Location = new System.Drawing.Point(456, 395);
            this.buttonCrudGrilla.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonCrudGrilla.Name = "buttonCrudGrilla";
            this.buttonCrudGrilla.Size = new System.Drawing.Size(167, 30);
            this.buttonCrudGrilla.TabIndex = 8;
            this.buttonCrudGrilla.Text = "CrudGrilla";
            this.buttonCrudGrilla.UseVisualStyleBackColor = true;
            this.buttonCrudGrilla.Click += new System.EventHandler(this.buttonCrudGrilla_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(456, 257);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(167, 27);
            this.button2.TabIndex = 10;
            this.button2.Text = "OBSERVACIONES";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnRutas
            // 
            this.btnRutas.Location = new System.Drawing.Point(456, 448);
            this.btnRutas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRutas.Name = "btnRutas";
            this.btnRutas.Size = new System.Drawing.Size(167, 33);
            this.btnRutas.TabIndex = 11;
            this.btnRutas.Text = "RUTAS";
            this.btnRutas.UseVisualStyleBackColor = true;
            this.btnRutas.Click += new System.EventHandler(this.btnRutas_Click);
            // 
            // btnPersonalizado4
            // 
            this.btnPersonalizado4.ForeColor = System.Drawing.Color.Green;
            this.btnPersonalizado4.Location = new System.Drawing.Point(456, 171);
            this.btnPersonalizado4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonalizado4.Name = "btnPersonalizado4";
            this.btnPersonalizado4.Size = new System.Drawing.Size(167, 28);
            this.btnPersonalizado4.TabIndex = 12;
            this.btnPersonalizado4.Text = "CALLES";
            this.btnPersonalizado4.UseVisualStyleBackColor = true;
            this.btnPersonalizado4.Click += new System.EventHandler(this.btnPersonalizado4_Click);
            // 
            // btnPersonalizado3
            // 
            this.btnPersonalizado3.ForeColor = System.Drawing.Color.Green;
            this.btnPersonalizado3.Location = new System.Drawing.Point(16, 324);
            this.btnPersonalizado3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonalizado3.Name = "btnPersonalizado3";
            this.btnPersonalizado3.Size = new System.Drawing.Size(133, 46);
            this.btnPersonalizado3.TabIndex = 9;
            this.btnPersonalizado3.Text = "observaciones";
            this.btnPersonalizado3.UseVisualStyleBackColor = true;
            this.btnPersonalizado3.Click += new System.EventHandler(this.btnPersonalizado3_Click);
            // 
            // btnPersonalizado2
            // 
            this.btnPersonalizado2.ForeColor = System.Drawing.Color.Green;
            this.btnPersonalizado2.Location = new System.Drawing.Point(456, 135);
            this.btnPersonalizado2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonalizado2.Name = "btnPersonalizado2";
            this.btnPersonalizado2.Size = new System.Drawing.Size(167, 28);
            this.btnPersonalizado2.TabIndex = 7;
            this.btnPersonalizado2.Text = "DOMICILIOS";
            this.btnPersonalizado2.UseVisualStyleBackColor = true;
            this.btnPersonalizado2.Click += new System.EventHandler(this.btnPersonalizado2_Click);
            // 
            // btnPersonalizado1
            // 
            this.btnPersonalizado1.ForeColor = System.Drawing.Color.Green;
            this.btnPersonalizado1.Location = new System.Drawing.Point(4, 36);
            this.btnPersonalizado1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonalizado1.Name = "btnPersonalizado1";
            this.btnPersonalizado1.Size = new System.Drawing.Size(172, 28);
            this.btnPersonalizado1.TabIndex = 6;
            this.btnPersonalizado1.Text = "btnPersonalizado1";
            this.btnPersonalizado1.UseVisualStyleBackColor = true;
            this.btnPersonalizado1.Click += new System.EventHandler(this.btnPersonalizado1_Click);
            // 
            // btnPersonalizado8
            // 
            this.btnPersonalizado8.ForeColor = System.Drawing.Color.Green;
            this.btnPersonalizado8.Location = new System.Drawing.Point(0, 0);
            this.btnPersonalizado8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonalizado8.Name = "btnPersonalizado8";
            this.btnPersonalizado8.Size = new System.Drawing.Size(133, 28);
            this.btnPersonalizado8.TabIndex = 21;
            this.btnPersonalizado8.Text = "completar";
            // 
            // btnPersonalizado9
            // 
            this.btnPersonalizado9.ForeColor = System.Drawing.Color.Green;
            this.btnPersonalizado9.Location = new System.Drawing.Point(456, 334);
            this.btnPersonalizado9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonalizado9.Name = "btnPersonalizado9";
            this.btnPersonalizado9.Size = new System.Drawing.Size(167, 28);
            this.btnPersonalizado9.TabIndex = 7;
            this.btnPersonalizado9.Text = "MEDIDORES";
            this.btnPersonalizado9.UseVisualStyleBackColor = true;
            this.btnPersonalizado9.Click += new System.EventHandler(this.btnPersonalizado9_Click);
            // 
            // btnPersonalizado5
            // 
            this.btnPersonalizado5.ForeColor = System.Drawing.Color.Green;
            this.btnPersonalizado5.Location = new System.Drawing.Point(456, 63);
            this.btnPersonalizado5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonalizado5.Name = "btnPersonalizado5";
            this.btnPersonalizado5.Size = new System.Drawing.Size(167, 28);
            this.btnPersonalizado5.TabIndex = 13;
            this.btnPersonalizado5.Text = "TELEFONOS";
            this.btnPersonalizado5.UseVisualStyleBackColor = true;
            this.btnPersonalizado5.Click += new System.EventHandler(this.btnPersonalizado5_Click);
            // 
            // btnPersonalizado6
            // 
            this.btnPersonalizado6.ForeColor = System.Drawing.Color.Green;
            this.btnPersonalizado6.Location = new System.Drawing.Point(456, 98);
            this.btnPersonalizado6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonalizado6.Name = "btnPersonalizado6";
            this.btnPersonalizado6.Size = new System.Drawing.Size(167, 28);
            this.btnPersonalizado6.TabIndex = 14;
            this.btnPersonalizado6.Text = "CODIGO POSTAL";
            this.btnPersonalizado6.UseVisualStyleBackColor = true;
            this.btnPersonalizado6.Click += new System.EventHandler(this.btnPersonalizado6_Click);
            // 
            // btnPersonalizado7
            // 
            this.btnPersonalizado7.ForeColor = System.Drawing.Color.Green;
            this.btnPersonalizado7.Location = new System.Drawing.Point(456, 27);
            this.btnPersonalizado7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonalizado7.Name = "btnPersonalizado7";
            this.btnPersonalizado7.Size = new System.Drawing.Size(167, 28);
            this.btnPersonalizado7.TabIndex = 15;
            this.btnPersonalizado7.Text = "CLIENTES";
            this.btnPersonalizado7.UseVisualStyleBackColor = true;
            this.btnPersonalizado7.Click += new System.EventHandler(this.btnPersonalizado7_Click);
            // 
            // gesTextBox1
            // 
            this.gesTextBox1.BackColor = System.Drawing.Color.White;
            this.gesTextBox1.ColorTextoVacio = System.Drawing.Color.Gray;
            this.gesTextBox1.Location = new System.Drawing.Point(75, 293);
            this.gesTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gesTextBox1.Name = "gesTextBox1";
            this.gesTextBox1.Requerido = Controles.util.Enumerados.enumRequerido.NO;
            this.gesTextBox1.Size = new System.Drawing.Size(100, 22);
            this.gesTextBox1.TabIndex = 16;
            this.gesTextBox1.TextoVacio = "<Descripcion>";
            this.gesTextBox1.TipoControl = Controles.util.Enumerados.enumTipos.Ninguna;
            this.gesTextBox1.TextChanged += new System.EventHandler(this.gesTextBox1_TextChanged_1);
            // 
            // gesTextBox2
            // 
            this.gesTextBox2.BackColor = System.Drawing.Color.White;
            this.gesTextBox2.ColorTextoVacio = System.Drawing.Color.Gray;
            this.gesTextBox2.Location = new System.Drawing.Point(75, 234);
            this.gesTextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gesTextBox2.Name = "gesTextBox2";
            this.gesTextBox2.Requerido = Controles.util.Enumerados.enumRequerido.NO;
            this.gesTextBox2.Size = new System.Drawing.Size(100, 22);
            this.gesTextBox2.TabIndex = 17;
            this.gesTextBox2.TextoVacio = "<Descripcion>";
            this.gesTextBox2.TipoControl = Controles.util.Enumerados.enumTipos.Ninguna;
            // 
            // gesTextBox3
            // 
            this.gesTextBox3.BackColor = System.Drawing.Color.White;
            this.gesTextBox3.ColorTextoVacio = System.Drawing.Color.Gray;
            this.gesTextBox3.Location = new System.Drawing.Point(75, 263);
            this.gesTextBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gesTextBox3.Name = "gesTextBox3";
            this.gesTextBox3.Requerido = Controles.util.Enumerados.enumRequerido.NO;
            this.gesTextBox3.Size = new System.Drawing.Size(100, 22);
            this.gesTextBox3.TabIndex = 18;
            this.gesTextBox3.TextoVacio = "<Descripcion>";
            this.gesTextBox3.TipoControl = Controles.util.Enumerados.enumTipos.Ninguna;
            // 
            // btnTiposMedidores
            // 
            this.btnTiposMedidores.Location = new System.Drawing.Point(456, 489);
            this.btnTiposMedidores.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTiposMedidores.Name = "btnTiposMedidores";
            this.btnTiposMedidores.Size = new System.Drawing.Size(167, 33);
            this.btnTiposMedidores.TabIndex = 19;
            this.btnTiposMedidores.Text = "Tipos de Medidores";
            this.btnTiposMedidores.UseVisualStyleBackColor = true;
            this.btnTiposMedidores.Click += new System.EventHandler(this.btnTiposMedidores_Click);
            // 
            // btnFabricantes
            // 
            this.btnFabricantes.Location = new System.Drawing.Point(456, 529);
            this.btnFabricantes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFabricantes.Name = "btnFabricantes";
            this.btnFabricantes.Size = new System.Drawing.Size(167, 33);
            this.btnFabricantes.TabIndex = 20;
            this.btnFabricantes.Text = "Fabricantes";
            this.btnFabricantes.UseVisualStyleBackColor = true;
            this.btnFabricantes.Click += new System.EventHandler(this.btnFabricantes_Click);
            // 
            // btnMedidoresModelos
            // 
            this.btnMedidoresModelos.ForeColor = System.Drawing.Color.Green;
            this.btnMedidoresModelos.Location = new System.Drawing.Point(456, 207);
            this.btnMedidoresModelos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMedidoresModelos.Name = "btnMedidoresModelos";
            this.btnMedidoresModelos.Size = new System.Drawing.Size(167, 43);
            this.btnMedidoresModelos.TabIndex = 12;
            this.btnMedidoresModelos.Text = "MODELOS DE MEDIDORES";
            this.btnMedidoresModelos.UseVisualStyleBackColor = true;
            this.btnMedidoresModelos.Click += new System.EventHandler(this.btnMedidoresModelos_Click);
            // 
            // btnMedidores
            // 
            this.btnMedidores.ForeColor = System.Drawing.Color.Green;
            this.btnMedidores.Location = new System.Drawing.Point(281, 63);
            this.btnMedidores.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMedidores.Name = "btnMedidores";
            this.btnMedidores.Size = new System.Drawing.Size(167, 28);
            this.btnMedidores.TabIndex = 12;
            this.btnMedidores.Text = "MEDIDORES";
            this.btnMedidores.UseVisualStyleBackColor = true;
            this.btnMedidores.Click += new System.EventHandler(this.btnMedidores_Click);
            // 
            // categorias
            // 
            this.categorias.ForeColor = System.Drawing.Color.Green;
            this.categorias.Location = new System.Drawing.Point(281, 27);
            this.categorias.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.categorias.Name = "categorias";
            this.categorias.Size = new System.Drawing.Size(167, 28);
            this.categorias.TabIndex = 22;
            this.categorias.Text = "CATEGORIAS";
            this.categorias.UseVisualStyleBackColor = true;
            this.categorias.Click += new System.EventHandler(this.categorias_Click);
            // 
            // btnMedidoresMasivos
            // 
            this.btnMedidoresMasivos.ForeColor = System.Drawing.Color.Green;
            this.btnMedidoresMasivos.Location = new System.Drawing.Point(281, 98);
            this.btnMedidoresMasivos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMedidoresMasivos.Name = "btnMedidoresMasivos";
            this.btnMedidoresMasivos.Size = new System.Drawing.Size(167, 48);
            this.btnMedidoresMasivos.TabIndex = 12;
            this.btnMedidoresMasivos.Text = "ALTA MASIVA DE MEDIDORES";
            this.btnMedidoresMasivos.UseVisualStyleBackColor = true;
            this.btnMedidoresMasivos.Click += new System.EventHandler(this.btnMedidoresMasivos_Click);
            // 
            // btnTiposConexiones
            // 
            this.btnTiposConexiones.ForeColor = System.Drawing.Color.Green;
            this.btnTiposConexiones.Location = new System.Drawing.Point(281, 154);
            this.btnTiposConexiones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTiposConexiones.Name = "btnTiposConexiones";
            this.btnTiposConexiones.Size = new System.Drawing.Size(167, 28);
            this.btnTiposConexiones.TabIndex = 12;
            this.btnTiposConexiones.Text = "Tipos de Conexiones";
            this.btnTiposConexiones.UseVisualStyleBackColor = true;
            this.btnTiposConexiones.Click += new System.EventHandler(this.btnTiposConexiones_Click);
            // 
            // btnDeptos
            // 
            this.btnDeptos.Location = new System.Drawing.Point(304, 187);
            this.btnDeptos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDeptos.Name = "btnDeptos";
            this.btnDeptos.Size = new System.Drawing.Size(125, 25);
            this.btnDeptos.TabIndex = 8;
            this.btnDeptos.Text = "Departamentos";
            this.btnDeptos.UseVisualStyleBackColor = true;
            this.btnDeptos.Click += new System.EventHandler(this.btnDeptos_Click);
            // 
            // btnLectura
            // 
            this.btnLectura.Location = new System.Drawing.Point(456, 567);
            this.btnLectura.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLectura.Name = "btnLectura";
            this.btnLectura.Size = new System.Drawing.Size(167, 33);
            this.btnLectura.TabIndex = 20;
            this.btnLectura.Text = "Lecturas de Conceptos";
            this.btnLectura.UseVisualStyleBackColor = true;
            this.btnLectura.Click += new System.EventHandler(this.btnLectura_Click);
            // 
            // btnTiposIva
            // 
            this.btnTiposIva.Location = new System.Drawing.Point(304, 217);
            this.btnTiposIva.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTiposIva.Name = "btnTiposIva";
            this.btnTiposIva.Size = new System.Drawing.Size(125, 25);
            this.btnTiposIva.TabIndex = 8;
            this.btnTiposIva.Text = "Tipos de Iva";
            this.btnTiposIva.UseVisualStyleBackColor = true;
            this.btnTiposIva.Click += new System.EventHandler(this.btnTiposIva_Click);
            // 
            // btnServicios
            // 
            this.btnServicios.Location = new System.Drawing.Point(304, 247);
            this.btnServicios.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnServicios.Name = "btnServicios";
            this.btnServicios.Size = new System.Drawing.Size(125, 30);
            this.btnServicios.TabIndex = 8;
            this.btnServicios.Text = "Servicios";
            this.btnServicios.UseVisualStyleBackColor = true;
            this.btnServicios.Click += new System.EventHandler(this.btnServicios_Click);
            // 
            // btnSuministros
            // 
            this.btnSuministros.Location = new System.Drawing.Point(304, 283);
            this.btnSuministros.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSuministros.Name = "btnSuministros";
            this.btnSuministros.Size = new System.Drawing.Size(125, 27);
            this.btnSuministros.TabIndex = 11;
            this.btnSuministros.Text = "Suministros";
            this.btnSuministros.UseVisualStyleBackColor = true;
            this.btnSuministros.Click += new System.EventHandler(this.btnSuministros_Click);
            // 
            // btnPersonas
            // 
            this.btnPersonas.ForeColor = System.Drawing.Color.Green;
            this.btnPersonas.Location = new System.Drawing.Point(247, 324);
            this.btnPersonas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonas.Name = "btnPersonas";
            this.btnPersonas.Size = new System.Drawing.Size(167, 28);
            this.btnPersonas.TabIndex = 23;
            this.btnPersonas.Text = "PERSONAS";
            this.btnPersonas.UseVisualStyleBackColor = true;
            this.btnPersonas.Click += new System.EventHandler(this.btnPersonas_Click);
            // 
            // btnUsuarios
            // 
            this.btnUsuarios.ForeColor = System.Drawing.Color.Green;
            this.btnUsuarios.Location = new System.Drawing.Point(0, 71);
            this.btnUsuarios.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUsuarios.Name = "btnUsuarios";
            this.btnUsuarios.Size = new System.Drawing.Size(167, 28);
            this.btnUsuarios.TabIndex = 24;
            this.btnUsuarios.Text = "USUARIOS";
            this.btnUsuarios.UseVisualStyleBackColor = true;
            this.btnUsuarios.Click += new System.EventHandler(this.btnUsuarios_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(456, 608);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(167, 33);
            this.button3.TabIndex = 25;
            this.button3.Text = "Modos Lecturas";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnTiposComprobantes
            // 
            this.btnTiposComprobantes.ForeColor = System.Drawing.Color.Green;
            this.btnTiposComprobantes.Location = new System.Drawing.Point(184, 494);
            this.btnTiposComprobantes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTiposComprobantes.Name = "btnTiposComprobantes";
            this.btnTiposComprobantes.Size = new System.Drawing.Size(229, 28);
            this.btnTiposComprobantes.TabIndex = 26;
            this.btnTiposComprobantes.Text = "TIPOS COMPROBANTES";
            this.btnTiposComprobantes.UseVisualStyleBackColor = true;
            this.btnTiposComprobantes.Click += new System.EventHandler(this.btnTiposComprobantes_Click);
            // 
            // btnRoles
            // 
            this.btnRoles.Location = new System.Drawing.Point(0, 106);
            this.btnRoles.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRoles.Name = "btnRoles";
            this.btnRoles.Size = new System.Drawing.Size(167, 41);
            this.btnRoles.TabIndex = 27;
            this.btnRoles.Text = "Roles";
            this.btnRoles.UseVisualStyleBackColor = true;
            this.btnRoles.Click += new System.EventHandler(this.btnRoles_Click);
            // 
            // btnConceptos
            // 
            this.btnConceptos.Location = new System.Drawing.Point(247, 570);
            this.btnConceptos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnConceptos.Name = "btnConceptos";
            this.btnConceptos.Size = new System.Drawing.Size(167, 33);
            this.btnConceptos.TabIndex = 28;
            this.btnConceptos.Text = "Conceptos";
            this.btnConceptos.UseVisualStyleBackColor = true;
            this.btnConceptos.Click += new System.EventHandler(this.btnConceptos_Click);
            // 
            // btnUnidadesMedida
            // 
            this.btnUnidadesMedida.Location = new System.Drawing.Point(4, 489);
            this.btnUnidadesMedida.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUnidadesMedida.Name = "btnUnidadesMedida";
            this.btnUnidadesMedida.Size = new System.Drawing.Size(167, 33);
            this.btnUnidadesMedida.TabIndex = 29;
            this.btnUnidadesMedida.Text = "Unidades de medida";
            this.btnUnidadesMedida.UseVisualStyleBackColor = true;
            this.btnUnidadesMedida.Click += new System.EventHandler(this.btnUnidadesMedida_Click);
            // 
            // btnBarrios
            // 
            this.btnBarrios.Location = new System.Drawing.Point(4, 542);
            this.btnBarrios.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBarrios.Name = "btnBarrios";
            this.btnBarrios.Size = new System.Drawing.Size(167, 33);
            this.btnBarrios.TabIndex = 30;
            this.btnBarrios.Text = "Barrios";
            this.btnBarrios.UseVisualStyleBackColor = true;
            this.btnBarrios.Click += new System.EventHandler(this.btnBarrios_Click);
            // 
            // btnFuncionalidadesRoles
            // 
            this.btnFuncionalidadesRoles.Location = new System.Drawing.Point(0, 159);
            this.btnFuncionalidadesRoles.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFuncionalidadesRoles.Name = "btnFuncionalidadesRoles";
            this.btnFuncionalidadesRoles.Size = new System.Drawing.Size(167, 41);
            this.btnFuncionalidadesRoles.TabIndex = 31;
            this.btnFuncionalidadesRoles.Text = "FuncionalidadesRoles";
            this.btnFuncionalidadesRoles.UseVisualStyleBackColor = true;
            this.btnFuncionalidadesRoles.Click += new System.EventHandler(this.btnFuncionalidadesRoles_Click);
            // 
            // btnFuncionalidadesUsuarios
            // 
            this.btnFuncionalidadesUsuarios.Location = new System.Drawing.Point(0, 207);
            this.btnFuncionalidadesUsuarios.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFuncionalidadesUsuarios.Name = "btnFuncionalidadesUsuarios";
            this.btnFuncionalidadesUsuarios.Size = new System.Drawing.Size(188, 41);
            this.btnFuncionalidadesUsuarios.TabIndex = 32;
            this.btnFuncionalidadesUsuarios.Text = "FuncionalidadesUsuarios";
            this.btnFuncionalidadesUsuarios.UseVisualStyleBackColor = true;
            this.btnFuncionalidadesUsuarios.Click += new System.EventHandler(this.btnFuncionalidadesUsuarios_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 641);
            this.Controls.Add(this.btnFuncionalidadesUsuarios);
            this.Controls.Add(this.btnFuncionalidadesRoles);
            this.Controls.Add(this.btnBarrios);
            this.Controls.Add(this.btnUnidadesMedida);
            this.Controls.Add(this.btnConceptos);
            this.Controls.Add(this.btnRoles);
            this.Controls.Add(this.btnTiposComprobantes);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnUsuarios);
            this.Controls.Add(this.btnPersonas);
            this.Controls.Add(this.categorias);
            this.Controls.Add(this.btnLectura);
            this.Controls.Add(this.btnFabricantes);
            this.Controls.Add(this.btnTiposMedidores);
            this.Controls.Add(this.gesTextBox3);
            this.Controls.Add(this.gesTextBox2);
            this.Controls.Add(this.gesTextBox1);
            this.Controls.Add(this.btnPersonalizado7);
            this.Controls.Add(this.btnPersonalizado6);
            this.Controls.Add(this.btnPersonalizado5);
            this.Controls.Add(this.btnMedidoresMasivos);
            this.Controls.Add(this.btnTiposConexiones);
            this.Controls.Add(this.btnMedidores);
            this.Controls.Add(this.btnMedidoresModelos);
            this.Controls.Add(this.btnPersonalizado4);
            this.Controls.Add(this.btnSuministros);
            this.Controls.Add(this.btnRutas);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnPersonalizado3);
            this.Controls.Add(this.btnServicios);
            this.Controls.Add(this.btnTiposIva);
            this.Controls.Add(this.btnDeptos);
            this.Controls.Add(this.buttonCrudGrilla);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvTest);
            this.Controls.Add(this.btnPersonalizado9);
            this.Controls.Add(this.btnPersonalizado8);
            this.Controls.Add(this.btnPersonalizado2);
            this.Controls.Add(this.btnPersonalizado1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Controles.btnPersonalizado btnPersonalizado1;
        private Controles.btnPersonalizado btnPersonalizado2;
        private System.Windows.Forms.DataGridView dgvTest;
        private System.Windows.Forms.Button button1;
        private Controles.btnPersonalizado btnPersonalizado3;
        private System.Windows.Forms.Button buttonCrudGrilla;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnRutas;
        private Controles.btnPersonalizado btnPersonalizado4;
        private Controles.btnPersonalizado btnPersonalizado5;
        private Controles.btnPersonalizado btnPersonalizado6;
        private Controles.btnPersonalizado btnPersonalizado7;
        private Controles.textBoxes.gesTextBox gesTextBox1;
        private Controles.textBoxes.gesTextBox gesTextBox2;
        private Controles.textBoxes.gesTextBox gesTextBox3;
        private Controles.btnPersonalizado btnPersonalizado8;
        private Controles.btnPersonalizado btnPersonalizado9;
        private System.Windows.Forms.Button btnTiposMedidores;
        private System.Windows.Forms.Button btnFabricantes;
        private Controles.btnPersonalizado btnMedidoresModelos;
        private Controles.btnPersonalizado btnMedidores;
        private Controles.btnPersonalizado categorias;
        private Controles.btnPersonalizado btnMedidoresMasivos;
        private Controles.btnPersonalizado btnTiposConexiones;
        private System.Windows.Forms.Button btnDeptos;
        private System.Windows.Forms.Button btnLectura;
        private System.Windows.Forms.Button btnTiposIva;
        private System.Windows.Forms.Button btnServicios;
        private System.Windows.Forms.Button btnSuministros;
        private Controles.btnPersonalizado btnPersonas;
        private Controles.btnPersonalizado btnUsuarios;
        private System.Windows.Forms.Button button3;
        private Controles.btnPersonalizado btnTiposComprobantes;
        private System.Windows.Forms.Button btnRoles;
        private System.Windows.Forms.Button btnConceptos;
        private System.Windows.Forms.Button btnUnidadesMedida;
        private System.Windows.Forms.Button btnBarrios;
        private System.Windows.Forms.Button btnFuncionalidadesRoles;
        private System.Windows.Forms.Button btnFuncionalidadesUsuarios;
    }
}

