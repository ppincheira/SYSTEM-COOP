namespace Model
{

    public class Localidades {
        public Localidades() {}
        public virtual int LocNumero { get; set; }
        public virtual string PrvCodigo { get; set; }
        public virtual string LocDescripcion { get; set; }
        public virtual string TloCodigo { get; set; }
    }
}
