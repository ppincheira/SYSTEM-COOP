using System;
using System.Text;
using System.Collections.Generic;


namespace Model {
    
    public class TiposBarriosLocalidades {
        public TiposBarriosLocalidades() {
//			BarriosLocalidades = new List<BarriosLocalidade>();
        }
        public virtual string TblCodigo { get; set; }
        public virtual string TblDescripcion { get; set; }
//        public virtual IList<BarriosLocalidade> BarriosLocalidades { get; set; }
    }
}
