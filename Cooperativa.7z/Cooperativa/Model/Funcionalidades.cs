using System;
using System.Text;
using System.Collections.Generic;


namespace Model {
    
    public class Funcionalidades {
        public Funcionalidades() {
        }
        public virtual string FunCodigo { get; set; }
        public virtual string FunDescripcion { get; set; }
        public virtual string FunFuncionalidad { get; set; }
        public virtual string SbsCodigo { get; set; }
        public virtual int ffoCodigo { get; set; }
        
    }
}
