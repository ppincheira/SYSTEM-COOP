﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Enumeration
    {
        public enum Acciones { New, Edit, Del, Exp, Imp};

        public enum TelefonosTipos { Telefono,Email,Ninguna }

    }
}
