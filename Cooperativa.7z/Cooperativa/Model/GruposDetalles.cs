using System;
using System.Text;
using System.Collections.Generic;


namespace Model {

    public class GruposDetalles {
        public GruposDetalles()
        {
        }
        public virtual long GrdCodigo { get; set; }
        public virtual string GrdCodigoRegistro { get; set; }
        public virtual long GrpCodigo { get; set; }
    
    }
}
