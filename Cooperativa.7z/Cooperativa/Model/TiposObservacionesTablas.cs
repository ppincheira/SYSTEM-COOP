using System;
using System.Text;
using System.Collections.Generic;


namespace Model {
    
    public class TiposObservacionesTablas {
        public TiposObservacionesTablas() {
        }
        public virtual string TabCodigo { get; set; }
        public virtual string TobCodigo { get; set; }
        public virtual string TobDescripcion { get; set; }
     
    }
}
