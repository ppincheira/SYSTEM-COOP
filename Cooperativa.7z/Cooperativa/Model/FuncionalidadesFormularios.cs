﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class FuncionalidadesFormularios
    {
        public FuncionalidadesFormularios()
        {
        }
        public virtual int FfoCodigo { get; set; }
        public virtual string FfoNombre { get; set; }
        public virtual string FfoTitulo { get; set; }

    }
}
