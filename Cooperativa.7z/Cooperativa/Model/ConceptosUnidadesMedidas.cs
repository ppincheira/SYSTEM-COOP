﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ConceptosUnidadesMedidas
    {
        public virtual int cumCodigo { get; set; } // 5 numero no null
        public virtual string cumDescripcion { get; set; }//30 caracteres no null
    }
}
