using System;
using System.Text;
using System.Collections.Generic;


namespace Model {
    
    public class FuncionalidadesUsuarios {
        public FuncionalidadesUsuarios() { 
        }
        public virtual string FunCodigo { get; set; }
        public virtual int UsrNumero { get; set; }
        public virtual string RolCodigo { get; set; }
    }
}
