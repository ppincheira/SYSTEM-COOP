using System;
using System.Text;
using System.Collections.Generic;


namespace Model {
    
    public class Areas {
        public Areas() {
//			Departamentos = new List<Departamentos>();
        }
        public virtual string AreCodigo { get; set; }
        public virtual string AreDescripcion { get; set; }
 //       public virtual IList<Departamentos> Departamentos { get; set; }
    }
}
