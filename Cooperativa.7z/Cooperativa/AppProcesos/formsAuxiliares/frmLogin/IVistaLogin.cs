﻿using Controles.datos;
using Controles.contenedores;
using System;

namespace AppProcesos.formsAuxiliares.formLogin
{
    public interface IVistaLogin
    {
        string usuario { get; set; }
        string password { get; set; }
//        string login { set; }

    }
}
