﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Controles.datos;

namespace AppProcesos.formsAuxiliares.principal
{
    public interface IVistaPrincipal
    {

        trvMenu oTreeNode { get; set; }

        
    }
}
