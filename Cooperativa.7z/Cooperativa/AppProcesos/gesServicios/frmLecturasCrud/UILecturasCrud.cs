﻿using Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Business;
using System.Data;

namespace AppProcesos.gesServicios.frmLecturasCrud
{
    public class UILecturasCrud
    {

        private IVistaLecturasCrud _vista;
        Utility oUtil;


        public UILecturasCrud(IVistaLecturasCrud vista)
        {
            _vista = vista;
            oUtil = new Utility();
        }

        public void Inicializar()
        {
            _vista.dtFechaDesde = DateTime.Now.AddMonths(-1);
            _vista.dtFechaHasta = DateTime.Now;

        }

        public void CargarLecturaSuministro(long sumNumero)
        {

            //_vista.strSuministro = oLecSuministro.lesCodigo.ToString();

            Suministros oSuministro = new Suministros();
            SuministrosBus oSuministrosBus = new SuministrosBus();
            oSuministro = oSuministrosBus.SuministrosGetById(sumNumero);
            _vista.sumNumero = oSuministro.SumNumero;
            _vista.strSuministro = oSuministro.SumNumero.ToString();
            EstadosBus oEstadoBus = new EstadosBus();
            Estados oEstado = new Estados();
            oEstado = oEstadoBus.EstadosGetById(oSuministro.EstCodigo, "SUMINISTROS");
            _vista.strEstado = oEstado.EstDescripcion;
            ServiciosZonas oServicioZona = new ServiciosZonas();
            ServiciosZonasBus oServicioZonaBus = new ServiciosZonasBus();
            oServicioZona = oServicioZonaBus.ServiciosZonasGetById(oSuministro.SzoNumero);
            _vista.strZona = oServicioZona.SzoDescripcion;
            Empresas oEmpresa = new Empresas();
            EmpresasBus oEmpresaBus = new EmpresasBus();
            oEmpresa = oEmpresaBus.EmpresasGetById(oSuministro.EmpNumero);
            _vista.strCUIT = oEmpresa.EmpCuit;
            _vista.strTitular = oEmpresa.EmpRazonSocial == "" ? oEmpresa.EmpApellidos + " " + oEmpresa.EmpNombres : oEmpresa.EmpRazonSocial;
            /****Medidor ***/





            _vista.strRuta = oSuministro.SumOrdenRuta.ToString();
            _vista.strFechaAlta = oSuministro.SumFechaAlta.ToString("dd/MM/yyyy");
            _vista.strRegistrador = oSuministro.SumRegistrador.ToString();
            //_vista.strNroSuministro = oSuministro.SumNumero.ToString();




        }
        public void FormatearGrilla(){
            _vista.grdiLecturas.Columns[0].Visible = false;
            _vista.grdiLecturas.Columns[1].Width = 200;
            _vista.grdiLecturas.Columns[2].Width = 70;
            _vista.grdiLecturas.Columns[3].Width = 70;
            _vista.grdiLecturas.Columns[4].Width = 80;
            _vista.grdiLecturas.Columns[5].Width = 80;
            _vista.grdiLecturas.Columns[6].Width = 70;
        }
        public void CargarLecturaAsociada(long sumNumero,string Periodo)
        {
            LecturasSuministrosBus oLecSuministroBus = new LecturasSuministrosBus();
            LecturasSuministros oLecSuministro = new LecturasSuministros();

            DataTable dtLecturas = oLecSuministroBus.LecturasSuministrosGetByIdSuministro(sumNumero, Periodo);
            oUtil.CargarGrilla(_vista.grdiLecturas, dtLecturas);
            FormatearGrilla();
        }

    }
}
